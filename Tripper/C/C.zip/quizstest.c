#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<time.h>

struct test {
    int s_cau;
    char c_hoi[1000];
    //-- dap an --//
    char A_ndung[1000];
    char B_ndung[1000];
    char C_ndung[1000];
    char D_ndung[1000];
};

// ------------------- khai bao ham -------------------

void listTest(struct test a[], int n);
void printTest (struct test a[], int n);
void randomTest (struct test a[], int n, int r, char filename[]);
void saveFile (struct test a[], int n, char filename[]);
void readFile (struct test a[], int n, char filename[]);

// ------------------- nhap cau hoi -------------------
void listTest (struct test a[], int n) {
    for (int i = 0; i < n ; i++) {
        printf("cau so: %d \n",i+1);
        fflush(stdin);
        printf("nhap cau hoi: \n");
        gets(a[i].c_hoi);
        printf("nhap dap an: \n");
        printf("A: ");
        fflush(stdin);
        gets(a[i].A_ndung);
        printf("B: ");
        fflush(stdin);
        gets(a[i].B_ndung);
        printf("C: ");
        fflush(stdin);
        gets(a[i].C_ndung);
        printf("D: ");
        fflush(stdin);
        gets(a[i].D_ndung);
    }
}

// -------------------in bai test ra mang hinh -------------------
void printTest (struct test a[], int n) {
    printf("\n-------------- list test ---------------\n");
    for (int i = 0; i < n ; i++) {
        printf("\ncau hoi so %d : %-15s \n",i+1, a[i].c_hoi); 
        printf("A: %-15s \t B: %-15s \t C: %-15s \t D: %-15s",a[i].A_ndung, a[i].B_ndung, a[i].C_ndung, a[i].D_ndung);
    }
}

// -------------------xuat random test-------------------
void randomTest (struct test a[],int n, int r, char filename[]) {
    FILE *fpl;
    fpl = fopen (filename,"r");
    char ch;
    while ((ch = fgetc(fpl)) != EOF) {
        printf("%c", ch);
    }
   int random,i;
   printf("%d test trong 0 đến %d",&r,&n);
   while (r--) { 
    random = rand() %1000 + 1;
    printf("%d", random);
   }
   for (i = 0; i < r ; i++) {
        i = random;
    }
    fclose(fpl);

    printf("\ncau hoi so %d : %-15s \n",i, a[i].c_hoi); 
    printf("A: %-15s \t B: %-15s \t C: %-15s \t D: %-15s",a[i].A_ndung, a[i].B_ndung, a[i].C_ndung, a[i].D_ndung);
       
    return 0;
} 

// --------------------- save file ---------------------
void saveFile (struct test a[], int n, char filename[]) {
    FILE *fpl;
    fpl = fopen(filename, "w+");
    for (int i = 0; i < n; i++){
        fprintf(fpl,"\ncau hoi so %d : %-15s \n",i+1, a[i].c_hoi);
        fprintf(fpl,"A: %-15s \t B: %-15s \t C: %-15s \t D: %-15s",a[i].A_ndung, a[i].B_ndung, a[i].C_ndung, a[i].D_ndung);
    }
    
    fclose(fpl);
}

// --------------------- read file ---------------------
void readFile (struct test a[], int n, char filename[]) {
    FILE *fpl;
    fpl = fopen (filename,"r");
    char ch;
    while ((ch = fgetc(fpl)) != EOF) {
        printf("%c", ch);
    }

    fclose(fpl);
}
// ------------------- dem so cau dung -------------------- 


// ------------------- khoi tao main ----------------------
int main () {
    
    char filename[] = "test.txt";
    struct test a[100];
    int n;

    printf("\n <<------->> create list quizs choise <<-------->> \n");
    

    // ---- make menu choise --- //

    int key;
    do {
        printf ("\n \n");
        printf ("     <>------- menu choice -----------<>\n");
        printf ("     <>-----1/: nhap du lieu cau hoi--<>\n");
        printf ("     <>-----2/: hien danh sach cau hoi<>\n");
        printf ("     <>-----3/: lam bai test ---------<>\n");
        printf ("     <>-------------------------------<>\n");
        printf ("     <>---------nhap lua chon---------<>\n");
        fflush(stdin);   
        scanf("%d", &key);
        printf("\n <<------->> create list quizs choise <<-------->> \n");
        switch (key) {
            case 1:
                printf ("\n<>--------- nhap du lieu cau hoi -----<>\n");
                printf("nhap so cau hoi: \n");
                scanf("%d",&n);
                listTest(a,n);
                printTest(a,n);
                saveFile(a,n,filename);
                printf("\n <<------->> --------------- <<-------->> \n");
                break;
            case 2:
                printf("\n <<------->> create list quizs choise <<-------->> \n");
                printf ("\n<>--------- danh sach cau hoi -----<>\n");
                readFile(a,n,filename);
                printf("\n <<------->> --------------- <<-------->> \n");
                break;
            case 3:
                printf("\n <<------->> create list quizs choise <<-------->> \n");
                printf ("\n<>--------- lam bai kiem tra -----<>\n");
                int r;
                printf("random test: \n");
                scanf("%d",r);
                randomTest(a,n,r,filename);
                printf("\n <<------->> --------------- <<-------->> \n");
                break;
            default:
                printf ("\n<>----- end test -----<>\n");
                break;
        }
    } while (key != '0');

    return 1;
}

